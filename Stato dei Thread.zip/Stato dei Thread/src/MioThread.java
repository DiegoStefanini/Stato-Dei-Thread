public class MioThread implements Runnable {
    private int x;
    private int i;
    public MioThread(int par) {
        this.x = par;
    }
    public void run () {
        for (; i != x; i++) {
            try {
                Thread.sleep(120);
            } catch (InterruptedException e) {}
        }
    }
    public int Progresso()  {
        return i;
    }
    public int FinoA() {
        return x;
    }
}
