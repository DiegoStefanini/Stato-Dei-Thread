import java.util.Scanner;
public class Main {
    public static boolean check(int n, MioThread[] A) {
        for (int i = 0; i != n; i++) {
            if (A[i].Progresso() != A[i].FinoA()) {
                return true;
            }
        }
        return false;
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int nThread, N, X;
        boolean continua = true;
        System.out.println("Quanti Thread vuoi creare ?");
        nThread = input.nextInt();
        MioThread[] TuttiThread = new MioThread[nThread];
        System.out.println("Inserisci N: ");
        N = input.nextInt();
        Thread a;
        for (int i = 0; i != nThread; i++) {
            X = (int) (Math.random() * (N + 1));
            TuttiThread[i] = new MioThread(X);
            a = new Thread(TuttiThread[i]);
            a.start();
        }
        while (check(nThread, TuttiThread)) {
            for (int i = 0; i != nThread; i++) {
                if (TuttiThread[i].Progresso() != TuttiThread[i].FinoA()) {
                    System.out.println("Il Thread numero " + i + " è arrivato a " + TuttiThread[i].Progresso() + "/" + TuttiThread[i].FinoA());
                } else {
                    System.out.println("Il Thread numero " + i + " è compleatato");

                }
            }
        }

        System.out.println("TUTTI I THREAD SONO COMPLETATI");

    }


}
